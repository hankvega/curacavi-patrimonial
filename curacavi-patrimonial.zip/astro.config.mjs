import { defineConfig } from 'astro/config';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  vite: {
    plugins: [tailwindcss()],
  },
  site: 'https://curacavipatrimonial.cl',
  // base: '/nombre-repo/', // descomenta si usas GitHub Pages en subruta
});
